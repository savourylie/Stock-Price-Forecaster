# Building a Trading Robot
## Machine Learning Engineer Nanodegree
**Calvin Ku**
**September 27, 2016**

## Definition
### Project Overview
Problem with trading is that you never know when is the best time to buy or sell a stock, as you never know if the stock price will go up or go down in the future. This simple trading bot is an attempt to solve this problem.

Given the historical data of a stock, our chimp will tell you whether you should buy or sell or hold a particular stock (in our case, the SPY).

#### Data used in this project
The only data used in this project is the SPY historical data collected from Yahoo Finance. The data ranges from January 29, 1993 to September 6, 2016.

### Problem Statement
This project is about building a trading robot, or we can call it a trading bot. The trading bot is built to give the common user suggestions on whether to buy or sell or hold a particular stock on a particular trading day. The goal of this project is to build a trading bot that can beat a random monkey bot. Inpired by the famous saying of Princeton University professor Burton Malkiel in 1973 that "A blindfolded monkey throwing darts at a newspaper’s financial pages could select a portfolio that would do just as well as one carefully selected by experts” and the Forbes article [Any Monkey Can Beat the Market](http://www.forbes.com/sites/rickferri/2012/12/20/any-monkey-can-beat-the-market/#da3bf2d6e8b6), instead of competing on a portfolio basis, we set our battlefield on the SPY ETF.

We will use SPY as an example in this project but the same method can be applied to any stock. In the end we will evaluate our method by giving the monkey bot (which chooses the three actions equally on a random basis) and our chimp (the trading bot) 1000 dollars and see how they perform through the year 2015 and 2016 on SPY.


### Metrics
In this project we use the cash in hand plus the portfolio value (number of shares in hand times the market price) as the metric and define the reward function as the differnce of the metrics between the current state and the previous.

This simple metric is in line with what we want the trading bot to achieve in that our ultimate goal is to get as much as possible given what we have put into the market, and it doesn't matter whether it's in cash or in shares.

## Analysis
### Data Exploration
####First look
Let's first take a glance at our data and see if there's any missing values

![Checking missing values](./missing_values.png)

and the first few lines:
![Alt text](./raw_head.png)

We can see that we have six columns: Open, High, Low, Close, Volume, Adj Close. The Adj Close is the closing price of that day adjusted for "future" dividends payout and splits. For our usage, we will need to adjust the rest of columns as well.

### Exploratory Visualization
Now let's have a look on the performance of the ETF itself:
![Alt text](./Screen Shot 2016-09-27 at 6.46.19 PM.png)

Starting from the beginning, the stock price generally has a upward trend, with a bad time from 2001 to 2003 and the crush at the end of 2008. If we were given 1000 dollars from the beginning and went all in, we would have made 7001.05 dollars at the year end of 2014. This can be verified from below:
##### Initial Condition
$Cash_{init} = 1000$
$Share_{init} = 0$
$PV_{init} = 0$
##### Start
$Share_{start} = floor(\frac{1000.00}{28.31}) = 35$
$PV_{start} = 28.31 \cdot 35 = 990.79$
$Cash_{start} = Cash_{init} - 28.31 \cdot 35 = 9.21$
$Cash_{start} + PV_{start} = 9.21 + 990.79 = 1000.00$
##### End
$Share_{end} = 35$
$PV_{end} = 200.03 \cdot 35 = 7001.05$
$Cash_{end} = 9.21$
$Cash_{end} + PV_{end} = 9.21 + 7001.05 = 7010.26$

We can calculate the annual ROI by solving the following equation for $r$:
$$
(1 + r)^{10.92} = 7.001
$$

$$
\Longrightarrow r = 0.1950763 \approx 19.51\%
$$

We call this the ROI of the patient trader, and this can be used as a benchmark in the later section.

### Algorithms and Techniques
#### Algorithms
The trading bot (from now on we refer to it as the *chimp*) consists of two parts. In the first part we implement Q-learning and run it through the historical data for some number of iterations to construct the Q-table. The chimp can then go with the optimal policy by following the action of which the state-action pair has the maximum Q value. However, since the state space is vast and the coverage of the Q-table is very small, in the second part we use KNN to train on the Q-table and make predictions for the unseen states.

##### Reinfocement learning
###### Q-learning
The idea of reinforcement learning is simple.
1. The chimp senses its environment (data of some sort)
2. The chimp takes an action
3. The chimp gets a reward for that action she took
4. The chimp "remembers" the association between the state-action pair and the reward, so next time when she is in the same situation, she'd carry out the action that she thinks best, under the condition that,
5. The chimp has a really good memory so she doesn't just remember the immediate reward for each state-action pair, she also remembers all the rewards that are prior to and lead to the current state-action pair so that she can maximize the total reward she gets.

One way to do this is to use a method called Q-learning. At the core of Q-learning is the Bellman equation.

In each iteration we use the Bellman equation to update the cell of our Q-table:
$$
Q(s, a) \longleftarrow (1 - \alpha) \ Q(s, a) + \alpha \ (R(s) + \gamma  \ max_{a'} Q(s', a'))
$$

where $\alpha$ is the learning rate, $R(s)$ the reward function, and $\gamma$ the discount factor.
And then the chimp will follow the policy:
$$
\pi(s) = argmax_{a}Q(s, a)
$$

Although we don't have the Q value of any state action pair to begin with, the reward function contains the "real" information and throughout the iterations that information will slowly propagate to each state-action pair. At some point the Q values will converge (hopefully), and we end up with a Q table in equilibrium.

###### Exploration-exploitation dilemma
However, there's a catch. How does the chimp know what to do before she has learned anything?

To begin with, the chimp goes out and explores the world, sensing new data as she goes, and taking actions.

One important concept of reinforcement learning is the **exploration-exploitation dilemma**. Essentially it means when we take an action, we have to choose between whether to explore new possibilities, or just to follow what we've known to be best, to the best of our knowledge. And of course, if we don't know much, then following that limited knowledge of ours wouldn't make much sense. On the other hand, if we've already known pretty much everything, then there's just not much to explore and wandering around mindlessly wouldn't make sense either.

To implement this concept, we want our chimp set out not having bias (not that she's got much anyways), so we introduce the variable $\epsilon$, which represents the possibility of the chimp taking random actions. Initially we set $\epsilon = 1$ , and gradually decreases its value as the chimp getting to know more and more about its environment.

##### KNN
As said earlier, the state space is vast and there is no chance our data can cover all the use cases. Therefore, for any unseen state we use KNN to "simulate" the Q value of that state and then let the chimp pick the action that yields the maximum Q.

The principle of KNN (K-nearest-neighbor) is quite simple. It compares the new data point with training set and find K data points that are "nearest" to it by some predefined metric. Then it returns the average of the target variables of those K data points and assign it to the new data.

### Benchmark
We test our chimp against 100,000 random monkeys and the patient trader we have defined earlier. Since these two naive traders don't get influenced by the media or manipulated by the market makers, they are proven to perform better than the average investor. We are happy as long as our chimp can perform better than the two naive traders.

## Methodology
### Data Preprocessing
#### Adjust prices
![Alt text](./raw_prices.png)

As said earlier, we need to adjust the prices of Open, High, Low, Close, Volume. This can be done by getting the adjustment fact by dividing Adj Close by Close. We then multiply the prices by this factor, and divide the volume by this factor. 

![Alt text](./adj_prices.png)

#### Features engineering using volume price analysis
Volume price analysis has been around for over 100 years, and there are many legendary traders who made themselves famous using it. In addition to this, the basic principle behind it kind of makes sense on its own, that:
1. Price can only be moved by volume; large spread pushed by large volume and small spread by low volume
2. If it's not the case, then there's an anomaly, and you need to be cautious

But then people tend to think of it as an art rather than science, in that even though you have some clues what's going on on the market, you still don't know what the best timing is. 

For we data scientists, everything is science, including art. If a human can stare at the candlesticks telling you when to buy or sell, so can a computer. Thus the following features are extracted from the raw dataset:

For volume:
* -1d Volume
* -2d Volume
* -3d Volume
* -4d Volume
* -5d Volume
* 10d Average Volume
* 21d Average Volume
* 63d Average Volume

For price:
* -1d Spread
* -2d Spread
* -3d Spread
* -4d Spread
* -5d Spread
* 10d Spread
* 21d Spread
* 63d Spread

For wick:
* -1d upperwick/lowerwick
* -2d upperwick/lowerwick
* -3d upperwick/lowerwick
* -4d upperwick/lowerwick
* -5d upperwick/lowerwick
* 10d upperwick/lowerwick
* 21d upperwick/lowerwick
* 63d upperwick/lowerwick

Since to implement Q-learning we need to make the variables discrete. We use 100 day maximum and 100 day average to divide the above features and get relative levels of those features.

#### Trading price
We set the trading price of each trading day to be:
$$
Trade Price = 0.3 \ Open + 0.7 \ AdjClose
$$
This information is not available to the chimp. The properties of the chimp get updated with this information when she places an order. The portfolio value also gets updated using this price.

The reason for the slight lean to the closing price is because so that when a common user tries to follow the chimp suggestion, he or she still has time to do so.

## Implementation
We divide this section into the training section and the testing section.

In the training section, we first set up the benchmarks (the monkey and the patient trader), to see how they perform throughout the training dataset. And then see how much can our chimp can fit the data.

In the testing section, we let them compete again, this time using completely new dataset.

Note that in our simulation, without loss of generality, we set the transaction cost to be 0 to simplify our problem.

### Training section
#### The Monkey

